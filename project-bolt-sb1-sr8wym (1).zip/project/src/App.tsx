import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Game from './pages/Game';
import Loading from './pages/Loading';
import Stats from './pages/Stats';
import Shop from './pages/Shop';
import Layout from './components/Layout';

function App() {
  return (
    <BrowserRouter>
      <Toaster position="top-center" />
      <Routes>
        <Route path="/" element={<Loading />} />
        <Route element={<Layout />}>
          <Route path="/game" element={<Game />} />
          <Route path="/stats" element={<Stats />} />
          <Route path="/shop" element={<Shop />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;