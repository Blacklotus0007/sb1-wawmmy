import React from 'react';
import { Trophy } from 'lucide-react';
import { LEVELS } from '../config/gameConfig';
import { useGameStore } from '../store/gameStore';

export default function LevelCard() {
  const { level, totalTaps } = useGameStore();
  const currentLevel = LEVELS.find(l => l.id === level);
  const nextLevel = LEVELS.find(l => l.id === level + 1);

  if (!currentLevel) return null;

  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="text-yellow-400" />
        <h2 className="text-xl font-bold">Level {level}</h2>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{currentLevel.icon}</span>
          <span className="font-bold">{currentLevel.name}</span>
        </div>

        {nextLevel && (
          <>
            <div className="h-2 bg-white/20 rounded-full mt-4">
              <div
                className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"
                style={{
                  width: `${Math.min(
                    ((totalTaps - currentLevel.requiredTaps) /
                    (nextLevel.requiredTaps - currentLevel.requiredTaps)) * 100,
                    100
                  )}%`
                }}
              />
            </div>
            <div className="text-sm text-gray-300">
              Next: {nextLevel.name} ({nextLevel.requiredTaps - totalTaps} taps remaining)
            </div>
          </>
        )}
      </div>
    </div>
  );
}