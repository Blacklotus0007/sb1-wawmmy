import React from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { Home, ShoppingBag, BarChart2, Trophy, Settings } from 'lucide-react';
import { motion } from 'framer-motion';

export default function Layout() {
  const location = useLocation();

  const navItems = [
    { path: '/game', icon: Home, label: 'Home' },
    { path: '/shop', icon: ShoppingBag, label: 'Shop' },
    { path: '/stats', icon: BarChart2, label: 'Stats' },
    { path: '/leaderboard', icon: Trophy, label: 'Ranks' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  return (
    <div className="min-h-screen pb-24">
      <Outlet />
      
      <motion.nav 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="fixed bottom-0 left-0 right-0 glass-effect border-t border-white/20"
      >
        <div className="container mx-auto px-4">
          <div className="flex justify-around py-2">
            {navItems.map(({ path, icon: Icon, label }) => (
              <Link
                key={path}
                to={path}
                className={`nav-item ${location.pathname === path ? 'active' : 'text-white/60'}`}
              >
                <Icon size={24} />
                <span className="text-xs">{label}</span>
              </Link>
            ))}
          </div>
        </div>
      </motion.nav>
    </div>
  );
}