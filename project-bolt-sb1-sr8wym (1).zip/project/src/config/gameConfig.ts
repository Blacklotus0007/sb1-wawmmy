export const LEVELS = [
  { id: 1, name: "Novice Tapper", requiredTaps: 0, bonus: 0, icon: "⚡" },
  { id: 2, name: "Quick Fingers", requiredTaps: 1000, bonus: 100, icon: "🔥" },
  { id: 3, name: "Lightning Hand", requiredTaps: 5000, bonus: 500, icon: "⚡" },
  { id: 4, name: "Thunder Master", requiredTaps: 10000, bonus: 1000, icon: "🌩" },
  { id: 5, name: "Pulse Legend", requiredTaps: 50000, bonus: 5000, icon: "👑" },
  { id: 6, name: "Tap God", requiredTaps: 100000, bonus: 10000, icon: "🌟" },
];

export const DAILY_BONUSES: { day: number; amount: number }[] = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  amount: Math.floor(10 * Math.pow(2, i / 2))
}));

export const DAILY_VIDEOS = [
  {
    id: "video1",
    title: "Game Tutorial",
    url: "https://youtube.com/watch?v=example1",
    reward: 500,
  },
  {
    id: "video2",
    title: "Pro Tips & Tricks",
    url: "https://youtube.com/watch?v=example2",
    reward: 750,
  },
  {
    id: "video3",
    title: "Secret Strategies",
    url: "https://youtube.com/watch?v=example3",
    reward: 1000,
  },
];

export const REFERRAL_BONUS = 5000;
export const PREMIUM_REFERRAL_BONUS = 15000;

export const ACTIVITY_MULTIPLIERS = {
  TAP: 1.1,
  DAILY_BONUS: 1.2,
  VIDEO_WATCH: 1.15,
  REFERRAL: 1.3,
  LEVEL_UP: 1.25,
};