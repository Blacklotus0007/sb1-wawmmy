import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { addDays, isAfter, startOfDay } from 'date-fns';
import { LEVELS, DAILY_BONUSES, DAILY_VIDEOS, ACTIVITY_MULTIPLIERS, REFERRAL_BONUS, PREMIUM_REFERRAL_BONUS } from '../config/gameConfig';
import type { Level, DailyBonus, VideoTask } from '../types/game';
import toast from 'react-hot-toast';

interface GameState {
  coins: number;
  tapPower: number;
  baseIncomePerHour: number;
  lastDailyBonus: string | null;
  lastTapTime: string | null;
  currentDay: number;
  level: number;
  totalTaps: number;
  referralCount: number;
  premiumReferralCount: number;
  incomeMultiplier: number;
  dailyVideos: VideoTask[];
  socialTasksCompleted: string[];
  upgrades: Upgrade[];
  tasks: Task[];
  showConfetti: boolean;
  
  // Actions
  addCoins: (amount: number) => void;
  incrementTaps: () => void;
  claimDailyBonus: () => void;
  completeVideo: (videoId: string) => void;
  addReferral: (isPremium: boolean) => void;
  upgradeTapPower: (upgradeId: string) => void;
  calculateIncomePerHour: () => number;
  setLastTapTime: (time: string) => void;
  setShowConfetti: (show: boolean) => void;
}

const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      coins: 0,
      tapPower: 1,
      baseIncomePerHour: 0,
      lastDailyBonus: null,
      lastTapTime: null,
      currentDay: 1,
      level: 1,
      totalTaps: 0,
      referralCount: 0,
      premiumReferralCount: 0,
      incomeMultiplier: 1,
      dailyVideos: DAILY_VIDEOS.map(v => ({ ...v, completed: false })),
      socialTasksCompleted: [],
      upgrades: initialUpgrades,
      tasks: initialTasks,
      showConfetti: false,

      setLastTapTime: (time) => set({ lastTapTime: time }),
      setShowConfetti: (show) => set({ showConfetti: show }),

      addCoins: (amount) => set((state) => {
        const newAmount = amount * state.incomeMultiplier;
        if (newAmount >= 1000) {
          toast.success(`+${Math.floor(newAmount).toLocaleString()} coins!`);
        }
        return { coins: state.coins + newAmount };
      }),

      incrementTaps: () => set((state) => {
        const newTotalTaps = state.totalTaps + 1;
        const currentLevel = LEVELS.find(l => l.id === state.level);
        const nextLevel = LEVELS.find(l => l.id === state.level + 1);
        
        let updates: Partial<GameState> = {
          totalTaps: newTotalTaps,
          incomeMultiplier: state.incomeMultiplier * ACTIVITY_MULTIPLIERS.TAP
        };

        if (nextLevel && newTotalTaps >= nextLevel.requiredTaps) {
          updates = {
            ...updates,
            level: nextLevel.id,
            coins: state.coins + nextLevel.bonus,
            incomeMultiplier: state.incomeMultiplier * ACTIVITY_MULTIPLIERS.LEVEL_UP
          };
          toast.success(`Level Up! You're now ${nextLevel.name}! 🎉`);
        }

        return updates as GameState;
      }),

      // ... rest of the store implementation remains the same ...

    }),
    {
      name: 'pulse-tap-storage',
    }
  )
);