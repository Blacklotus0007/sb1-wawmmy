import React, { useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGameStore } from '../store/gameStore';
import { Zap, Coins, AlertCircle } from 'lucide-react';
import toast from 'react-hot-toast';
import Confetti from 'react-confetti';
import DailyBonusCard from '../components/DailyBonusCard';
import LevelCard from '../components/LevelCard';
import VideoTasks from '../components/VideoTasks';
import { differenceInHours } from 'date-fns';

export default function Game() {
  const { 
    coins, 
    tapPower,
    addCoins, 
    incrementTaps,
    calculateIncomePerHour,
    lastTapTime,
    setLastTapTime,
    showConfetti,
    setShowConfetti
  } = useGameStore();

  useEffect(() => {
    const interval = setInterval(() => {
      const incomePerHour = calculateIncomePerHour();
      if (incomePerHour > 0) {
        addCoins(incomePerHour / 3600);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [addCoins, calculateIncomePerHour]);

  useEffect(() => {
    if (lastTapTime) {
      const hoursSinceLastTap = differenceInHours(new Date(), new Date(lastTapTime));
      if (hoursSinceLastTap >= 24) {
        toast((t) => (
          <div className="flex items-center gap-2">
            <AlertCircle className="text-yellow-400" />
            <span>Hey! Remember to check your pulse today!</span>
          </div>
        ), {
          duration: 5000,
          position: 'top-center',
          icon: '⚡',
        });
      }
    }
  }, [lastTapTime]);

  const handleTap = () => {
    addCoins(tapPower);
    incrementTaps();
    setLastTapTime(new Date().toISOString());
    
    if (Math.random() < 0.05) { // 5% chance for confetti
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 3000);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <AnimatePresence>
        {showConfetti && <Confetti />}
      </AnimatePresence>

      <motion.div 
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="text-center mb-8"
      >
        <div className="flex items-center justify-center gap-2 text-3xl font-bold">
          <Coins className="text-yellow-400" />
          <span className="bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent">
            {Math.floor(coins).toLocaleString()}
          </span>
        </div>
        <div className="text-sm text-gray-300 mt-1">
          Power: {tapPower}/tap | {calculateIncomePerHour()}/hour
        </div>
      </motion.div>

      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={handleTap}
        className="tap-button mx-auto"
      >
        <Zap size={64} className="text-white relative z-10" />
      </motion.button>

      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="mt-8 space-y-4"
      >
        <LevelCard />
        <DailyBonusCard />
        <VideoTasks />
      </motion.div>
    </div>
  );
}